#pragma once
#include <SFML/Graphics.hpp>
#include <SFML\Audio.hpp>
#include <iostream>
class Points
{
public:
	Points();
	~Points();

	void PointSystem(sf::RenderWindow& window, int FlappyPoints, int bestscore, int PointPositionX, int PointPositionY);
	void PointSystem1(sf::RenderWindow& window, int FlappyPoints, int bestscore, int PointPositionX, int PointPositionY);
	sf::Texture ZERO, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE;
	sf::Sprite sZERO, sONE, sTWO, sTHREE, sFOUR, sFIVE, sSIX, sSEVEN, sEIGHT, sNINE,sZERO1, sONE1, sTWO1, sTHREE1, sFOUR1, sFIVE1, sSIX1, sSEVEN1, 
	    sEIGHT1, sNINE1, sONEDouble, sTWODouble, sTHREEDouble,sFOURDouble, sFIVEDouble, 
		sSIXDouble, sSEVENDouble, sEIGHTDouble, sNINEDouble;
};

