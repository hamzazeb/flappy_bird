#include "GameOver.h"
#include "Pipes.h"
#include <SFML/Graphics.hpp>
#include <SFML\Audio.hpp>
#include <iostream>

GameOver::GameOver()
{
	if (!Game_Over.loadFromFile("images/gameover11.png"))
	{
	}
	Game_over_Sprite.setTexture(Game_Over);
	Game_over_Sprite.setScale(1, 1);
	Game_over_Sprite.setPosition(165, 690);

	if (!ScoreBoard.loadFromFile("images/scoreboard1.png"))
	{
	}
	ScoreBoardSprite.setTexture(ScoreBoard);
	ScoreBoardSprite.setScale(1, 1);
	ScoreBoardSprite.setPosition(145, 800);

	if (!BronzeMedal.loadFromFile("images/FlappyBird.png", sf::IntRect(112, 477, 22, 22)))
	{
	}
	BronzeMedalSprite.setTexture(BronzeMedal);
	BronzeMedalSprite.setScale(4, 4);
	BronzeMedalSprite.setPosition(205, 900);
	if (!SilverMedal.loadFromFile("images/FlappyBird.png", sf::IntRect(112, 453, 22, 22)))
	{
	}
	SilverMedalSprite.setTexture(SilverMedal);
	SilverMedalSprite.setScale(4, 4);
	SilverMedalSprite.setPosition(205, 900);
	if (!GoldMedal.loadFromFile("images/FlappyBird.png", sf::IntRect(121, 282, 22, 22)))
	{
	}
	GoldMedalSprite.setTexture(GoldMedal);
	GoldMedalSprite.setScale(4, 4);
	GoldMedalSprite.setPosition(205, 900);
	if (!PlatinumMedal.loadFromFile("images/FlappyBird.png", sf::IntRect(121, 258, 22, 22)))
	{
	}
	PlatinumMedalSprite.setTexture(PlatinumMedal);
	PlatinumMedalSprite.setScale(4, 4);
	PlatinumMedalSprite.setPosition(205, 900);
}


GameOver::~GameOver()
{
}

void GameOver::PipeCollision(sf::RenderWindow &window, bool isGameOver, int points)
{

	if (isGameOver)
	{
		if (ScoreBoardSprite.getPosition().y <= 230)
		{
			ScoreBoardSpeed = 0;
			//ScoreBoardVelocity = 0;
		}

		ScoreBoardSprite.move(0, ScoreBoardSpeed);
		Game_over_Sprite.move(0, ScoreBoardSpeed);
		window.draw(Game_over_Sprite);
		window.draw(ScoreBoardSprite);
		if (points >= 10 && points < 30)
		{
			window.draw(BronzeMedalSprite);
			BronzeMedalSprite.move(0, ScoreBoardSpeed);
		}
		else if (points >= 30 && points < 50)
		{
			window.draw(SilverMedalSprite);
			SilverMedalSprite.move(0, ScoreBoardSpeed);
		}
		else if (points >= 50 && points < 80)
		{
			window.draw(GoldMedalSprite);
			GoldMedalSprite.move(0, ScoreBoardSpeed);
		}
		else if (points >= 80 && points)
		{
			window.draw(PlatinumMedalSprite);
			PlatinumMedalSprite.move(0, ScoreBoardSpeed);
		}
	}

}

