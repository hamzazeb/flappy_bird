#include <SFML/Graphics.hpp>
#include <iostream>
//#include <fstream>
#include <string>
#include "Pipes.h"
#include "Points.h"
#include "Menu.h"

using namespace std;

int main()
{play:
	sf::Vector2f velocity(sf::Vector2f(0, 0));
	sf::Vector2u windowSize(800, 600);
	sf::Vector2i NumberPosition(380, 40);
	const float gravity = 0.3;
	int groundHeight = 580;
	int FlappyPoints = 0;
	int AngleIncrease = -30;
	int AngleDownfall = 1;
	float moveSpeed = 5, jumpSpeed = 2;
	float Angle = 0;
	int bestscore = 0;
	int x = 95, x1 = 450;

	bool Once = false;
	bool OnePerPoint = false;
	bool CollisionHit = false;
	bool GameStart = false;
	bool GameOverSoundFix = false;
	bool GameOverSoundFix1 = false;
	bool SecondHitPrevent = true;

	Points numbers,bestscore1;

	GameOver End;
//////////////////////////////////////////////////////////////////////////  background music	
	sf::SoundBuffer BGMusic;
	sf::Sound BackGroundMusic;
	if (!BGMusic.loadFromFile("audio/FreeKO_Fame.ogg"))
	{
	}
	BackGroundMusic.setBuffer(BGMusic);
	BackGroundMusic.play();
	BackGroundMusic.setVolume(25);
	
///////////////////////////////////////////////////////////////////////////	

  sf::RenderWindow window1(sf::VideoMode(800, 600), "FlappyBird By Hamza Zeb");
 // Create a graphical text to display

sf::Texture pTexture;
sf::Sprite playerImage;
if(!pTexture.loadFromFile("images/background2.png"))
	std::cout<<"Error In Loding Image"<<std::endl;

playerImage.setTexture(pTexture);
//playerImage.setPosition(100,100);
    Menu menu(window1.getSize().x, window1.getSize().y);
   // Start the game loop
    while (window1.isOpen())
    {
        // Process events
        sf::Event event;
        while (window1.pollEvent(event))
        {		
			switch (event.type)
			{
			case sf::Event::KeyPressed:
				switch (event.key.code)
				{
				case sf::Keyboard::Up:
					menu.MoveUp();
					break;

				case sf::Keyboard::Down:
					menu.MoveDown();
					break;

				case sf::Keyboard::Return:
					switch (menu.GetPressedItem())
					{
					case 0:
						window1.close();
						break;
					case 1:
						x+=25 ;//////////////////////////////////////// level 2nd
						window1.close();
						break;
					case 2:
						x+=10;
						x1-=150;//////////////////////////////////////// level 3rd
						window1.close();
						break;
					case 3:
						return 0;
						break;	
					}

					break;
				}

				break;
			case sf::Event::Closed:
				window1.close();

				break;

			}        	
        
        
        
		/*	if(event.type == sf::Event::KeyPressed)
			{
				if(event.key.code == sf::Keyboard::F)
				{	
					window1.close();
				}
				else if(event.key.code == sf::Keyboard::S)
				{	
					window1.close();
					x+=25 ;//////////////////////////////////////// level 2nd
				}
				else if(event.key.code == sf::Keyboard::T)
				{	
					window1.close();
					x+=10;
					x1-=150;//////////////////////////////////////// level 3rd
				}
				else if(event.key.code == sf::Keyboard::Escape)
				{	
					return EXIT_SUCCESS;
				}		
			}*/	
        }
    window1.draw(playerImage);
    menu.draw(window1);

        // Update the window
        window1.display();
    }

Pipes pipe1(800, 378, 0, 830);
Pipes pipe2(800, 378, x1, 830);/// first was 450  // second was 300

	sf::RenderWindow window(sf::VideoMode(windowSize.x, windowSize.y), "FlappyBird By Hamza Zeb");
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////// Sprites
	sf::Texture Flappy, BackGround;
	sf::Sprite FlappyBird, BackGroundSprite;
	if (!Flappy.loadFromFile("images/flappy.png"))
	{
	}
	if (!BackGround.loadFromFile("images/background1.png" ))
	{
	}
	BackGroundSprite.setTexture(BackGround);
	BackGroundSprite.setScale(1,1);
	FlappyBird.setTexture(Flappy);
	FlappyBird.setPosition(200, 300);
	FlappyBird.setScale(0.08, 0.08);
	////////////////////////////////////////////////////////////////////////////////////////////////////////////  Audio
	sf::SoundBuffer FlappyJump, FlappyPoint, FlappyCollision;
	sf::Sound FlappyJumpSound, FlappyPointSound, FlappyCollisionSound;
	if (!FlappyJump.loadFromFile("audio/sfx_wing.wav"))
	{
	}
	if (!FlappyPoint.loadFromFile("audio/sfx_point.wav"))
	{
	}
	if (!FlappyCollision.loadFromFile("audio/sfx_hit.wav"))
	{
	}
	FlappyJumpSound.setBuffer(FlappyJump);
	FlappyPointSound.setBuffer(FlappyPoint);
	FlappyCollisionSound.setBuffer(FlappyCollision);
	
	window.setFramerateLimit(x);	/////////////////// frame speed

	std::cout << FlappyPoints << std::endl;

	while (window.isOpen())
	{
		sf::Event event;
		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::Closed)
				window.close();
		}
// here we wait for the user to press Space to start the game
		while (!GameStart)
		{
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up))
			GameStart = true;
		sf::Event event;
		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::Closed)
				window.close();
		}
			window.clear();
			window.draw(BackGroundSprite);
			window.draw(FlappyBird);
			window.display();

		}
		///////////////////////////////////////////////////////////////////// Here we got the controls for the birdy
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
		{
			velocity.x = moveSpeed;
		}
		else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
		{
			velocity.x = -moveSpeed;
		}
		else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up))
		{
			if(!Once)
			{

				Angle = AngleIncrease;
				if (!CollisionHit)
				{
					velocity.y = 0;
					FlappyJumpSound.play();
				}
					velocity.y += -jumpSpeed * 3;		// birdy movment upward
					
				Once = true;
			}
	    }
		else
		{
			velocity.x = 0;
			Once = false;
		}
		FlappyBird.move(velocity.x, velocity.y);



			FlappyBird.setRotation(Angle);

			if (sf::Keyboard::isKeyPressed(sf::Keyboard::Return))
			{
			//	window.close();
				goto play;
			}
//Here we draw the scoreboard and halt all moevements when we hit the pipe
		if ((pipe1.OverlapTest(FlappyBird.getPosition().x, FlappyBird.getPosition().y)) ||
			(pipe2.OverlapTest(FlappyBird.getPosition().x, FlappyBird.getPosition().y)))
		{
			if (GameOverSoundFix)
			{
				NumberPosition.y += -6;
				if (NumberPosition.y <= 300)
				{
					NumberPosition.y = 300;
				}
			}
			else
			{
				FlappyCollisionSound.play();
				pipe1.Speed = 0;
				pipe2.Speed = 0;
				moveSpeed = 0;
				jumpSpeed = 0;
				NumberPosition.x = 545;
				NumberPosition.y = 870;
				AngleDownfall = 20;
				AngleIncrease = 10;
				GameOverSoundFix = true;
				SecondHitPrevent = false;//this boolean is used to prevent the floor collision from activating and redrawing stuff unnecesary. 
				CollisionHit = true;

			}
		}
// Here we got the point system
		if (pipe1.Points(FlappyBird.getPosition().x) || pipe2.Points(FlappyBird.getPosition().x))
		{
			if (!OnePerPoint)
			{

				FlappyPoints++;
				/*/////////////////////////////////////////////////////////// file handling
				ofstream ofile;
				int hk = 0;
				if (hk == 0)
				{
				ofile.open("BestScore.txt",ios::out);
				ofile.put(FlappyPoints);
				ofile.close();
				}
				hk++;
	*/			
				FlappyPointSound.play();
				std::cout << FlappyPoints << std::endl;
				OnePerPoint = true;
			}
		}
		else
			OnePerPoint = false;

		///////////////////////////////////////////////////////////////////////////////////////// Here we have collision for the ground
		if (FlappyBird.getPosition().y + FlappyBird.getScale().y < groundHeight || velocity.y < 0)      // We draw the scoreboard and halt all movements here
		{ 
			velocity.y += gravity;
		}
		else
		{
			if (SecondHitPrevent)//this is used so that we dont draw and stop/pause the game twice after we hit the pipe(because we fall down and hit the floor then). it becomes false at the pipe version of this
			{
				if (GameOverSoundFix1)
				{
					NumberPosition.y += -9;
					if (NumberPosition.y <= 300)
					{
						NumberPosition.y = 300;
					}
				}
				else
				{
					FlappyBird.setPosition(FlappyBird.getPosition().x, groundHeight - FlappyBird.getScale().y);
					velocity.y = 0;
					CollisionHit = true;
					FlappyCollisionSound.play();
					pipe1.Speed = 0;
					pipe2.Speed = 0;
					moveSpeed = 0;
					jumpSpeed = 0;
					NumberPosition.x = 545;
					NumberPosition.y = 870;
					AngleIncrease = 60;
					AngleDownfall = 3;
					GameOverSoundFix1 = true;
				}
			}
			else
			{
				FlappyBird.setPosition(FlappyBird.getPosition().x, groundHeight - FlappyBird.getScale().y);
				velocity.y = 0;
			}
		}
	/*		ifstream ifile;
				ifile.open("BestScore.txt",ios::in);
				int i = ifile.get();
	*/	
		if(Angle < 60)
		Angle += AngleDownfall;    // birdy angle
	//	bestscore = i;
		
		window.clear();
		window.draw(BackGroundSprite);
		pipe1.draw(window , x1 );
		pipe2.draw(window , x1 );
		window.draw(FlappyBird);
        End.PipeCollision(window, CollisionHit, FlappyPoints); //If we collide we draw "game over" here.
		numbers.PointSystem(window, FlappyPoints, bestscore, NumberPosition.x, NumberPosition.y); // 380 and 40(NumberPoisition) are the positions for the numbers on the screen while the game is in progress.	
	//	bestscore1.PointSystem1(window, FlappyPoints, bestscore, NumberPosition.x, NumberPosition.y);         // for file best score
		window.display();	
	}
	
	
	
		
	return EXIT_SUCCESS;
}
