#include "Points.h"



Points::Points()
{
	if (!ZERO.loadFromFile("images/FlappyBird.png", sf::IntRect(496, 60, 12, 18)))
	{
	}
	if (!ONE.loadFromFile("images/FlappyBird.png", sf::IntRect(136, 455, 8, 18)))
	{
	}
	if (!TWO.loadFromFile("images/FlappyBird.png", sf::IntRect(292, 160, 12, 18)))
	{
	}
	if (!THREE.loadFromFile("images/FlappyBird.png", sf::IntRect(306, 160, 12, 18)))
	{
	}
	if (!FOUR.loadFromFile("images/FlappyBird.png", sf::IntRect(320, 160, 12, 18)))
	{
	}
	if (!FIVE.loadFromFile("images/FlappyBird.png", sf::IntRect(334, 160, 12, 18)))
	{
	}
	if (!SIX.loadFromFile("images/FlappyBird.png", sf::IntRect(292, 184, 12, 18)))
	{
	}
	if (!SEVEN.loadFromFile("images/FlappyBird.png", sf::IntRect(306, 184, 12, 18)))
	{
	}
	if (!EIGHT.loadFromFile("images/FlappyBird.png", sf::IntRect(320, 184, 12, 18)))
	{
	}
	if (!NINE.loadFromFile("images/FlappyBird.png", sf::IntRect(334, 184, 12, 18)))
	{
	}

	sZERO.setTexture(ZERO);
	sONE.setTexture(ONE);
	sTWO.setTexture(TWO);
	sTHREE.setTexture(THREE);
	sFOUR.setTexture(FOUR);
	sFIVE.setTexture(FIVE);
	sSIX.setTexture(SIX);
	sSEVEN.setTexture(SEVEN);
	sEIGHT.setTexture(EIGHT);
	sNINE.setTexture(NINE);

	sONEDouble.setTexture(ONE);
	sTWODouble.setTexture(TWO);
	sTHREEDouble.setTexture(THREE);
	sFOURDouble.setTexture(FOUR);
	sFIVEDouble.setTexture(FIVE);
	sSIXDouble.setTexture(SIX);
	sSEVENDouble.setTexture(SEVEN);
	sEIGHTDouble.setTexture(EIGHT);
	sNINEDouble.setTexture(NINE);

	sONEDouble.setScale(2, 2);
	sTWODouble.setScale(2, 2);
	sTHREEDouble.setScale(2, 2);
	sFOURDouble.setScale(2, 2);
	sFIVEDouble.setScale(2, 2);
	sSIXDouble.setScale(2, 2);
	sSEVENDouble.setScale(2, 2);
	sEIGHTDouble.setScale(2, 2);
	sNINEDouble.setScale(2,2);

	sZERO.setScale(2, 2);
	sONE.setScale(2, 2);
	sTWO.setScale(2, 2);
	sTHREE.setScale(2, 2);
	sFOUR.setScale(2, 2);
	sFIVE.setScale(2, 2);
	sSIX.setScale(2, 2);
	sSEVEN.setScale(2, 2);
	sEIGHT.setScale(2, 2);
	sNINE.setScale(2, 2);
}


Points::~Points()
{
}

void Points::PointSystem(sf::RenderWindow& window, int FlappPointPositionYPoints, int bestflappyscore, int PointPositionX, int PointPositionY)
{
	if (FlappPointPositionYPoints > bestflappyscore )
		bestflappyscore = FlappPointPositionYPoints;
		
		
		sZERO.setPosition(PointPositionX, PointPositionY);
		sONE.setPosition(PointPositionX, PointPositionY);
		sTWO.setPosition(PointPositionX, PointPositionY);
		sTHREE.setPosition(PointPositionX, PointPositionY);
		sFOUR.setPosition(PointPositionX, PointPositionY);
		sFIVE.setPosition(PointPositionX, PointPositionY);
		sSIX.setPosition(PointPositionX, PointPositionY);
		sSEVEN.setPosition(PointPositionX, PointPositionY);
		sEIGHT.setPosition(PointPositionX, PointPositionY);
		sNINE.setPosition(PointPositionX, PointPositionY);	
		
		sZERO1.setPosition(PointPositionX, PointPositionY+70);
		sONE1.setPosition(PointPositionX, PointPositionY+70);
		sTWO1.setPosition(PointPositionX, PointPositionY+70);
		sTHREE1.setPosition(PointPositionX, PointPositionY+70);
		sFOUR1.setPosition(PointPositionX, PointPositionY+70);
		sFIVE1.setPosition(PointPositionX, PointPositionY+70);
		sSIX1.setPosition(PointPositionX, PointPositionY+70);
		sSEVEN1.setPosition(PointPositionX, PointPositionY+70);
		sEIGHT1.setPosition(PointPositionX, PointPositionY+70);
		sNINE1.setPosition(PointPositionX, PointPositionY+70);	
		
	if (FlappPointPositionYPoints < 10)
	{
		
		switch (FlappPointPositionYPoints)
		{
		case 0:
			window.draw(sZERO);
			break;
		case 1:
			window.draw(sONE);
			break;
		case 2:
			window.draw(sTWO);
			break;
		case 3:
			window.draw(sTHREE);
			break;
		case 4:
			window.draw(sFOUR);
			break;
		case 5:
			window.draw(sFIVE);
			break;
		case 6:
			window.draw(sSIX);
			break;
		case 7:
			window.draw(sSEVEN);
			break;
		case 8:
			window.draw(sEIGHT);
			break;
		case 9:
			window.draw(sNINE);
			break;
		}
	}
	if (FlappPointPositionYPoints < 20)
	{
		sONEDouble.setPosition(PointPositionX - 20, PointPositionY);

		switch (FlappPointPositionYPoints)
		{
		case 10:
			window.draw(sONEDouble);
			window.draw(sZERO);
			break;
		case 11:
			window.draw(sONEDouble);
			window.draw(sONE);
			break;
		case 12:
			window.draw(sONEDouble);
			window.draw(sTWO);
			break;
		case 13:
			window.draw(sONEDouble);
			window.draw(sTHREE);
			break;
		case 14:
			window.draw(sONEDouble);
			window.draw(sFOUR);
			break;
		case 15:
			window.draw(sONEDouble);
			window.draw(sFIVE);
			break;
		case 16:
			window.draw(sONEDouble);
			window.draw(sSIX);
			break;
		case 17:
			window.draw(sONEDouble);
			window.draw(sSEVEN);
			break;
		case 18:
			window.draw(sONEDouble);
			window.draw(sEIGHT);
			break;
		case 19:
			window.draw(sONEDouble);
			window.draw(sNINE);
			break;
		}
	}
	if (FlappPointPositionYPoints < 30)
	{
		sTWODouble.setPosition(PointPositionX - 20, PointPositionY);

		switch (FlappPointPositionYPoints)
		{
		case 20:
			window.draw(sTWODouble);
			window.draw(sZERO);
			break;
		case 21:
			window.draw(sTWODouble);
			window.draw(sONE);
			break;
		case 22:
			window.draw(sTWODouble);
			window.draw(sTWO);
			break;
		case 23:
			window.draw(sTWODouble);
			window.draw(sTHREE);
			break;
		case 24:
			window.draw(sTWODouble);
			window.draw(sFOUR);
			break;
		case 25:
			window.draw(sTWODouble);
			window.draw(sFIVE);
			break;
		case 26:
			window.draw(sTWODouble);
			window.draw(sSIX);
			break;
		case 27:
			window.draw(sTWODouble);
			window.draw(sSEVEN);
			break;
		case 28:
			window.draw(sTWODouble);
			window.draw(sEIGHT);
			break;
		case 29:
			window.draw(sTWODouble);
			window.draw(sNINE);
			break;
		}
	}
	if (FlappPointPositionYPoints < 40)
	{
		sTHREEDouble.setPosition(PointPositionX - 20, PointPositionY);

		switch (FlappPointPositionYPoints)
		{
		case 30:
			window.draw(sTHREEDouble);
			window.draw(sZERO);
			break;
		case 31:
			window.draw(sTHREEDouble);
			window.draw(sONE);
			break;
		case 32:
			window.draw(sTHREEDouble);
			window.draw(sTWO);
			break;
		case 33:
			window.draw(sTHREEDouble);
			window.draw(sTHREE);
			break;
		case 34:
			window.draw(sTHREEDouble);
			window.draw(sFOUR);
			break;
		case 35:
			window.draw(sTHREEDouble);
			window.draw(sFIVE);
			break;
		case 36:
			window.draw(sTHREEDouble);
			window.draw(sSIX);
			break;
		case 37:
			window.draw(sTHREEDouble);
			window.draw(sSEVEN);
			break;
		case 38:
			window.draw(sTHREEDouble);
			window.draw(sEIGHT);
			break;
		case 39:
			window.draw(sTHREEDouble);
			window.draw(sNINE);
			break;
		}
	}
		if (FlappPointPositionYPoints < 50)
	{
		sFOURDouble.setPosition(PointPositionX - 20, PointPositionY);

		switch (FlappPointPositionYPoints)
		{
		case 40:
			window.draw(sFOURDouble);
			window.draw(sZERO);
			break;
		case 41:
			window.draw(sFOURDouble);
			window.draw(sONE);
			break;
		case 42:
			window.draw(sFOURDouble);
			window.draw(sTWO);
			break;
		case 43:
			window.draw(sFOURDouble);
			window.draw(sTHREE);
			break;
		case 44:
			window.draw(sFOURDouble);
			window.draw(sFOUR);
			break;
		case 45:
			window.draw(sFOURDouble);
			window.draw(sFIVE);
			break;
		case 46:
			window.draw(sFOURDouble);
			window.draw(sSIX);
			break;
		case 47:
			window.draw(sFOURDouble);
			window.draw(sSEVEN);
			break;
		case 48:
			window.draw(sFOURDouble);
			window.draw(sEIGHT);
			break;
		case 49:
			window.draw(sFOURDouble);
			window.draw(sNINE);
			break;
		}
	}
	if (FlappPointPositionYPoints < 60)
	{
		sFIVEDouble.setPosition(PointPositionX - 20, PointPositionY);

		switch (FlappPointPositionYPoints)
		{
		case 50:
			window.draw(sFIVEDouble);
			window.draw(sZERO);
			break;
		case 51:
			window.draw(sFIVEDouble);
			window.draw(sONE);
			break;
		case 52:
			window.draw(sFIVEDouble);
			window.draw(sTWO);
			break;
		case 53:
			window.draw(sFIVEDouble);
			window.draw(sTHREE);
			break;
		case 54:
			window.draw(sFIVEDouble);
			window.draw(sFOUR);
			break;
		case 55:
			window.draw(sFIVEDouble);
			window.draw(sFIVE);
			break;
		case 56:
			window.draw(sFIVEDouble);
			window.draw(sSIX);
			break;
		case 57:
			window.draw(sFIVEDouble);
			window.draw(sSEVEN);
			break;
		case 58:
			window.draw(sFIVEDouble);
			window.draw(sEIGHT);
			break;
		case 59:
			window.draw(sFIVEDouble);
			window.draw(sNINE);
			break;
		}
	}
	if (FlappPointPositionYPoints < 70)
	{
		sSIXDouble.setPosition(PointPositionX - 20, PointPositionY);

		switch (FlappPointPositionYPoints)
		{
		case 60:
			window.draw(sSIXDouble);
			window.draw(sZERO);
			break;
		case 61:
			window.draw(sSIXDouble);
			window.draw(sONE);
			break;
		case 62:
			window.draw(sSIXDouble);
			window.draw(sTWO);
			break;
		case 63:
			window.draw(sSIXDouble);
			window.draw(sTHREE);
			break;
		case 64:
			window.draw(sSIXDouble);
			window.draw(sFOUR);
			break;
		case 65:
			window.draw(sSIXDouble);
			window.draw(sFIVE);
			break;
		case 66:
			window.draw(sSIXDouble);
			window.draw(sSIX);
			break;
		case 67:
			window.draw(sSIXDouble);
			window.draw(sSEVEN);
			break;
		case 68:
			window.draw(sSIXDouble);
			window.draw(sEIGHT);
			break;
		case 69:
			window.draw(sSIXDouble);
			window.draw(sNINE);
			break;
		}
	}
	if (FlappPointPositionYPoints < 80)
	{
		sSEVENDouble.setPosition(PointPositionX - 20, PointPositionY);

		switch (FlappPointPositionYPoints)
		{
		case 70:
			window.draw(sSEVENDouble);
			window.draw(sZERO);
			break;
		case 71:
			window.draw(sSEVENDouble);
			window.draw(sONE);
			break;
		case 72:
			window.draw(sSEVENDouble);
			window.draw(sTWO);
			break;
		case 73:
			window.draw(sSEVENDouble);
			window.draw(sTHREE);
			break;
		case 74:
			window.draw(sSEVENDouble);
			window.draw(sFOUR);
			break;
		case 75:
			window.draw(sSEVENDouble);
			window.draw(sFIVE);
			break;
		case 76:
			window.draw(sSEVENDouble);
			window.draw(sSIX);
			break;
		case 77:
			window.draw(sSEVENDouble);
			window.draw(sSEVEN);
			break;
		case 78:
			window.draw(sSEVENDouble);
			window.draw(sEIGHT);
			break;
		case 79:
			window.draw(sSEVENDouble);
			window.draw(sNINE);
			break;
		}
	}
	if (FlappPointPositionYPoints < 90)
	{
		sEIGHTDouble.setPosition(PointPositionX - 20, PointPositionY);

		switch (FlappPointPositionYPoints)
		{
		case 80:
			window.draw(sEIGHTDouble);
			window.draw(sZERO);
			break;
		case 81:
			window.draw(sEIGHTDouble);
			window.draw(sONE);
			break;
		case 82:
			window.draw(sEIGHTDouble);
			window.draw(sTWO);
			break;
		case 83:
			window.draw(sEIGHTDouble);
			window.draw(sTHREE);
			break;
		case 84:
			window.draw(sEIGHTDouble);
			window.draw(sFOUR);
			break;
		case 85:
			window.draw(sEIGHTDouble);
			window.draw(sFIVE);
			break;
		case 86:
			window.draw(sEIGHTDouble);
			window.draw(sSIX);
			break;
		case 87:
			window.draw(sEIGHTDouble);
			window.draw(sSEVEN);
			break;
		case 88:
			window.draw(sEIGHTDouble);
			window.draw(sEIGHT);
			break;
		case 89:
			window.draw(sEIGHTDouble);
			window.draw(sNINE);
			break;
		}
	}
	if (FlappPointPositionYPoints < PointPositionY)
	{
		sNINEDouble.setPosition(PointPositionX - 20, PointPositionY);

		switch (FlappPointPositionYPoints)
		{
		case 90:
			window.draw(sNINEDouble);
			window.draw(sZERO);
			break;
		case 91:
			window.draw(sNINEDouble);
			window.draw(sONE);
			break;
		case 92:
			window.draw(sNINEDouble);
			window.draw(sTWO);
			break;
		case 93:
			window.draw(sNINEDouble);
			window.draw(sTHREE);
			break;
		case 94:
			window.draw(sNINEDouble);
			window.draw(sFOUR);
			break;
		case 95:
			window.draw(sNINEDouble);
			window.draw(sFIVE);
			break;
		case 96:
			window.draw(sNINEDouble);
			window.draw(sSIX);
			break;
		case 97:
			window.draw(sNINEDouble);
			window.draw(sSEVEN);
			break;
		case 98:
			window.draw(sNINEDouble);
			window.draw(sEIGHT);
			break;
		case 99:
			window.draw(sNINEDouble);
			window.draw(sNINE);
			break;
		}
	}
}
void Points::PointSystem1(sf::RenderWindow& window,int FlappPointPositionYPoints, int bestflappyscore, int PointPositionX, int PointPositionY)
{
		if (FlappPointPositionYPoints > bestflappyscore )
			bestflappyscore = FlappPointPositionYPoints;
		
		sZERO1.setPosition(PointPositionX, PointPositionY+70);
		sONE1.setPosition(PointPositionX, PointPositionY+70);
		sTWO1.setPosition(PointPositionX, PointPositionY+70);
		sTHREE1.setPosition(PointPositionX, PointPositionY+70);
		sFOUR1.setPosition(PointPositionX, PointPositionY+70);
		sFIVE1.setPosition(PointPositionX, PointPositionY+70);
		sSIX1.setPosition(PointPositionX, PointPositionY+70);
		sSEVEN1.setPosition(PointPositionX, PointPositionY+70);
		sEIGHT1.setPosition(PointPositionX, PointPositionY+70);
		sNINE1.setPosition(PointPositionX, PointPositionY+70);	

///////// best score display

	if (bestflappyscore < 10)
	{
		
		switch (bestflappyscore)
		{
		case 0:
			window.draw(sZERO1);
			break;
		case 1:
			window.draw(sONE1);
			break;
		case 2:
			window.draw(sTWO1);
			break;
		case 3:
			window.draw(sTHREE1);
			break;
		case 4:
			window.draw(sFOUR1);
			break;
		case 5:
			window.draw(sFIVE1);
			break;
		case 6:
			window.draw(sSIX1);
			break;
		case 7:
			window.draw(sSEVEN1);
			break;
		case 8:
			window.draw(sEIGHT1);
			break;
		case 9:
			window.draw(sNINE1);
			break;
		}
	}
	if (bestflappyscore < 20)
	{
		sONEDouble.setPosition(PointPositionX - 20, PointPositionY+70);

		switch (bestflappyscore)
		{
		case 10:
			window.draw(sONEDouble);
			window.draw(sZERO1);
			break;
		case 11:
			window.draw(sONEDouble);
			window.draw(sONE1);
			break;
		case 12:
			window.draw(sONEDouble);
			window.draw(sTWO1);
			break;
		case 13:
			window.draw(sONEDouble);
			window.draw(sTHREE1);
			break;
		case 14:
			window.draw(sONEDouble);
			window.draw(sFOUR1);
			break;
		case 15:
			window.draw(sONEDouble);
			window.draw(sFIVE1);
			break;
		case 16:
			window.draw(sONEDouble);
			window.draw(sSIX1);
			break;
		case 17:
			window.draw(sONEDouble);
			window.draw(sSEVEN1);
			break;
		case 18:
			window.draw(sONEDouble);
			window.draw(sEIGHT1);
			break;
		case 19:
			window.draw(sONEDouble);
			window.draw(sNINE1);
			break;
		}
	}
	if (bestflappyscore < 30)
	{
		sTWODouble.setPosition(PointPositionX - 20, PointPositionY+70);

		switch (bestflappyscore)
		{
		case 20:
			window.draw(sTWODouble);
			window.draw(sZERO1);
			break;
		case 21:
			window.draw(sTWODouble);
			window.draw(sONE1);
			break;
		case 22:
			window.draw(sTWODouble);
			window.draw(sTWO1);
			break;
		case 23:
			window.draw(sTWODouble);
			window.draw(sTHREE1);
			break;
		case 24:
			window.draw(sTWODouble);
			window.draw(sFOUR1);
			break;
		case 25:
			window.draw(sTWODouble);
			window.draw(sFIVE1);
			break;
		case 26:
			window.draw(sTWODouble);
			window.draw(sSIX1);
			break;
		case 27:
			window.draw(sTWODouble);
			window.draw(sSEVEN1);
			break;
		case 28:
			window.draw(sTWODouble);
			window.draw(sEIGHT1);
			break;
		case 29:
			window.draw(sTWODouble);
			window.draw(sNINE1);
			break;
		}
	}
	if (bestflappyscore < 40)
	{
		sTHREEDouble.setPosition(PointPositionX - 20, PointPositionY+70);

		switch (bestflappyscore)
		{
		case 30:
			window.draw(sTHREEDouble);
			window.draw(sZERO1);
			break;
		case 31:
			window.draw(sTHREEDouble);
			window.draw(sONE1);
			break;
		case 32:
			window.draw(sTHREEDouble);
			window.draw(sTWO1);
			break;
		case 33:
			window.draw(sTHREEDouble);
			window.draw(sTHREE1);
			break;
		case 34:
			window.draw(sTHREEDouble);
			window.draw(sFOUR1);
			break;
		case 35:
			window.draw(sTHREEDouble);
			window.draw(sFIVE1);
			break;
		case 36:
			window.draw(sTHREEDouble);
			window.draw(sSIX1);
			break;
		case 37:
			window.draw(sTHREEDouble);
			window.draw(sSEVEN1);
			break;
		case 38:
			window.draw(sTHREEDouble);
			window.draw(sEIGHT1);
			break;
		case 39:
			window.draw(sTHREEDouble);
			window.draw(sNINE1);
			break;
		}
	}
		if (bestflappyscore < 50)
	{
		sFOURDouble.setPosition(PointPositionX - 20, PointPositionY+70);

		switch (bestflappyscore)
		{
		case 40:
			window.draw(sFOURDouble);
			window.draw(sZERO1);
			break;
		case 41:
			window.draw(sFOURDouble);
			window.draw(sONE1);
			break;
		case 42:
			window.draw(sFOURDouble);
			window.draw(sTWO1);
			break;
		case 43:
			window.draw(sFOURDouble);
			window.draw(sTHREE1);
			break;
		case 44:
			window.draw(sFOURDouble);
			window.draw(sFOUR1);
			break;
		case 45:
			window.draw(sFOURDouble);
			window.draw(sFIVE1);
			break;
		case 46:
			window.draw(sFOURDouble);
			window.draw(sSIX1);
			break;
		case 47:
			window.draw(sFOURDouble);
			window.draw(sSEVEN1);
			break;
		case 48:
			window.draw(sFOURDouble);
			window.draw(sEIGHT1);
			break;
		case 49:
			window.draw(sFOURDouble);
			window.draw(sNINE1);
			break;
		}
	}
	if (bestflappyscore < 60)
	{
		sFIVEDouble.setPosition(PointPositionX - 20, PointPositionY+70);

		switch (bestflappyscore)
		{
		case 50:
			window.draw(sFIVEDouble);
			window.draw(sZERO1);
			break;
		case 51:
			window.draw(sFIVEDouble);
			window.draw(sONE1);
			break;
		case 52:
			window.draw(sFIVEDouble);
			window.draw(sTWO1);
			break;
		case 53:
			window.draw(sFIVEDouble);
			window.draw(sTHREE1);
			break;
		case 54:
			window.draw(sFIVEDouble);
			window.draw(sFOUR1);
			break;
		case 55:
			window.draw(sFIVEDouble);
			window.draw(sFIVE1);
			break;
		case 56:
			window.draw(sFIVEDouble);
			window.draw(sSIX1);
			break;
		case 57:
			window.draw(sFIVEDouble);
			window.draw(sSEVEN1);
			break;
		case 58:
			window.draw(sFIVEDouble);
			window.draw(sEIGHT1);
			break;
		case 59:
			window.draw(sFIVEDouble);
			window.draw(sNINE1);
			break;
		}
	}
	if (bestflappyscore < 70)
	{
		sSIXDouble.setPosition(PointPositionX - 20, PointPositionY+70);

		switch (bestflappyscore)
		{
		case 60:
			window.draw(sSIXDouble);
			window.draw(sZERO1);
			break;
		case 61:
			window.draw(sSIXDouble);
			window.draw(sONE1);
			break;
		case 62:
			window.draw(sSIXDouble);
			window.draw(sTWO1);
			break;
		case 63:
			window.draw(sSIXDouble);
			window.draw(sTHREE1);
			break;
		case 64:
			window.draw(sSIXDouble);
			window.draw(sFOUR1);
			break;
		case 65:
			window.draw(sSIXDouble);
			window.draw(sFIVE1);
			break;
		case 66:
			window.draw(sSIXDouble);
			window.draw(sSIX1);
			break;
		case 67:
			window.draw(sSIXDouble);
			window.draw(sSEVEN1);
			break;
		case 68:
			window.draw(sSIXDouble);
			window.draw(sEIGHT1);
			break;
		case 69:
			window.draw(sSIXDouble);
			window.draw(sNINE1);
			break;
		}
	}
	if (bestflappyscore < 80)
	{
		sSEVENDouble.setPosition(PointPositionX - 20, PointPositionY+70);

		switch (bestflappyscore)
		{
		case 70:
			window.draw(sSEVENDouble);
			window.draw(sZERO1);
			break;
		case 71:
			window.draw(sSEVENDouble);
			window.draw(sONE1);
			break;
		case 72:
			window.draw(sSEVENDouble);
			window.draw(sTWO1);
			break;
		case 73:
			window.draw(sSEVENDouble);
			window.draw(sTHREE1);
			break;
		case 74:
			window.draw(sSEVENDouble);
			window.draw(sFOUR1);
			break;
		case 75:
			window.draw(sSEVENDouble);
			window.draw(sFIVE1);
			break;
		case 76:
			window.draw(sSEVENDouble);
			window.draw(sSIX1);
			break;
		case 77:
			window.draw(sSEVENDouble);
			window.draw(sSEVEN1);
			break;
		case 78:
			window.draw(sSEVENDouble);
			window.draw(sEIGHT1);
			break;
		case 79:
			window.draw(sSEVENDouble);
			window.draw(sNINE1);
			break;
		}
	}
	if (bestflappyscore < 90)
	{
		sEIGHTDouble.setPosition(PointPositionX - 20, PointPositionY+70);

		switch (bestflappyscore)
		{
		case 80:
			window.draw(sEIGHTDouble);
			window.draw(sZERO1);
			break;
		case 81:
			window.draw(sEIGHTDouble);
			window.draw(sONE1);
			break;
		case 82:
			window.draw(sEIGHTDouble);
			window.draw(sTWO1);
			break;
		case 83:
			window.draw(sEIGHTDouble);
			window.draw(sTHREE1);
			break;
		case 84:
			window.draw(sEIGHTDouble);
			window.draw(sFOUR1);
			break;
		case 85:
			window.draw(sEIGHTDouble);
			window.draw(sFIVE1);
			break;
		case 86:
			window.draw(sEIGHTDouble);
			window.draw(sSIX1);
			break;
		case 87:
			window.draw(sEIGHTDouble);
			window.draw(sSEVEN1);
			break;
		case 88:
			window.draw(sEIGHTDouble);
			window.draw(sEIGHT1);
			break;
		case 89:
			window.draw(sEIGHTDouble);
			window.draw(sNINE1);
			break;
		}
	}
	if (bestflappyscore < 100 )  //PointPositionY
	{
		sNINEDouble.setPosition(PointPositionX - 20, PointPositionY+70);

		switch (bestflappyscore)
		{
		case 90:
			window.draw(sNINEDouble);
			window.draw(sZERO1);
			break;
		case 91:
			window.draw(sNINEDouble);
			window.draw(sONE1);
			break;
		case 92:
			window.draw(sNINEDouble);
			window.draw(sTWO1);
			break;
		case 93:
			window.draw(sNINEDouble);
			window.draw(sTHREE1);
			break;
		case 94:
			window.draw(sNINEDouble);
			window.draw(sFOUR1);
			break;
		case 95:
			window.draw(sNINEDouble);
			window.draw(sFIVE1);
			break;
		case 96:
			window.draw(sNINEDouble);
			window.draw(sSIX1);
			break;
		case 97:
			window.draw(sNINEDouble);
			window.draw(sSEVEN1);
			break;
		case 98:
			window.draw(sNINEDouble);
			window.draw(sEIGHT1);
			break;
		case 99:
			window.draw(sNINEDouble);
			window.draw(sNINE1);
			break;
		}
	}	
	
		
}


